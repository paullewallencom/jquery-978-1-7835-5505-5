$(document).bind("mobileinit",  function() {
	$.mobile.defaultPageTransition = "none";
});
